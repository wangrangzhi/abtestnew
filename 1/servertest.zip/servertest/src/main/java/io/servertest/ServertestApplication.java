package io.servertest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServertestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServertestApplication.class, args);
	}
}
